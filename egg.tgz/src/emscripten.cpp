// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("emscripten"); }
int main(){
  announce();
  return lionss_run_workload("emscripten");
}
