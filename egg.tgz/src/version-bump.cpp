// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("version bump"); }
int main(){
  announce();
  return lionss_run_workload("version-bump");
}
